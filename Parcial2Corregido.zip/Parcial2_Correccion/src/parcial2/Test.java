package parcial2;

import config.AppConstants;
import java.util.Comparator;
import modelo.Animal;
import modelo.TipoAlimentacion;
import servicio.Zoologico;

public class Test {

    public static void main(String[] args) {
        try {
            // Crear un zoológico de animales
            Zoologico<Animal> zoologico = new Zoologico<>();
            zoologico.agregar(new Animal(2, "Leon", "Panthera leo",
                    TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(4, "Elefante", "Loxodonta",
                    TipoAlimentacion.HERBIVORO));
            zoologico.agregar(new Animal(3, "Oso", "Ursus arctos",
                    TipoAlimentacion.OMNIVORO));
            zoologico.agregar(new Animal(1, "Zorro", "Vulpes vulpes",
                    TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(5, "Gorila", "Gorilla gorilla",
                    TipoAlimentacion.OMNIVORO));
            // Mostrar todos los animales en el zoológico
            System.out.println("Inventario de animales:");
            zoologico.paraCadaElemento(animal -> System.out.println(animal));

            separador();
            // Filtrar animales por tipo de alimentación CARNIVORO
            System.out.println("Animales CARNIVOROS:");
            zoologico.filtrar(p -> p.getAlimentacion().equals(TipoAlimentacion.CARNIVORO))
                    .forEach(animal -> System.out.println(animal));

            separador();
            // Filtrar animales cuyo nombre contiene "León"
            System.out.println("Animales cuyo nombre contiene 'Leon':");
            //zoologico.filtrar((p -> p.getNombre().equals("Leon")))
            zoologico.filtrar((p -> p.getNombre().equals("Leon")))
                    .forEach(animal -> System.out.println(animal));

            separador();
            // Ordenar animales de manera natural (por id)
            System.out.println("Animales ordenados de manera natural (por id):");
            zoologico.ordenar();
            zoologico.paraCadaElemento(animal -> System.out.println(animal));

            separador();
            // Ordenar animales por nombre utilizando un Comparator
            System.out.println("Animales ordenados por nombre:");
            zoologico.ordenar(Comparator.comparing(Animal::getNombre));
            zoologico.paraCadaElemento(animal -> System.out.println(animal));

            // Guardar el zoológico en un archivo binario
            zoologico.serializar(AppConstants.SERIAL.toString());

            separador();
            // Cargar el zoológico desde el archivo binario
            Zoologico<Animal> zoologicoCargado = new Zoologico<>();
            zoologicoCargado.deserealizar(AppConstants.SERIAL.toString());
            System.out.println("Animales cargados desde archivo binario:");
            zoologicoCargado.paraCadaElemento(animal -> System.out.println(animal));

            // Guardar el zoológico en un archivo CSV
            zoologico.guardarCSV(AppConstants.CSV.toString());

            separador();
            // Cargar el zoológico desde el archivo CSV
            zoologicoCargado.cargarCSV(AppConstants.CSV.toString(), linea
                    -> Animal.fromCSV(linea));
            System.out.println("Animales cargados desde archivo CSV:");
            zoologicoCargado.paraCadaElemento(animal -> System.out.println(animal));

        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    public static void separador() {
        System.out.println("...........................................................................");
    }

}
